/*
  * This file will contain functions for room two.
  * It has yet to be designed.
  * Will be added to GameV2.html once some functions
  * can be or are called in EnvironmentV2.
*/

  var floor;
  var wall;
  var column;
  var platform;

  function initFloor(){

  }

  function initWall(){

  }
