/*
  * This file will contain sounds for the Game.
  * Sounds include music, environment sounds, character Sounds.
  * Character sounds are not necessarily dialogue.
  * This file has yet to be written.
  * This file has yet to be called in Environment.
  * This file has yet to be included in GameV2.html.
*/
